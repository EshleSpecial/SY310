#include <stdio.h>

int main()
{
    char a[6] = {'h', 'e', 'l', 'l', 'o', '\0'};
    char* b;

    b = a;
    return 0;
}
